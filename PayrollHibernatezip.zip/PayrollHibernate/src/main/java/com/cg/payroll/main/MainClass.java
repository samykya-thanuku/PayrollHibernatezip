package com.cg.payroll.main;
import java.sql.SQLException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.services.PayrollServices;

public class MainClass {

	public static void main(String[] args) throws SQLException {

		ApplicationContext applicationContext= new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices=(PayrollServices) applicationContext.getBean("services");
		int associateId=payrollServices.acceptAssociateDetails("samykya", "thanuku", "sam.com", "ece", "analyst", "Bcpo1234", 12344, 900, 10, 10, 1234667, "XYZ", "GJJ767");

		//payrollServices.updateAssociateDetails("Samykya", "thanuku", "ece", "analyst", "BCpohduf", "dsj", 12234, 10000, 1220, 211, 12345, "SAM", "DJU8");
		
		//int associateId=payrollServices.acceptAssociateDetails(firstName, lastName, emailId, department, designation, pancard, yearlyInvestmentUnder80C, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode)

	}
}


















/*		PayrollServices payrollServices = new PayrollServicesImpl();
		try{
			PayrollUtility.getDBConnection();
		//int associateID= payrollServices.acceptAssociateDetails("mani", "reddy", "mani.com", "eee", "analyst", "FHU788", 12000, 5000, 200, 100, 123456, "gyfg", "GUJH76");
			//System.out.println(associateID);
		//	int associateID= payrollServices.acceptAssociateDetails("anu", "reddy", "mani.com", "eee", "analyst", "FHU788", 12000, 5000, 200, 100, 123456, "gyfg", "GUJH76");
			//System.out.println(associateID);

			System.out.println(payrollServices.calculateNetSalary(101));
			//System.out.println(payrollServices.delete());


		}
		catch(PayrollServicesDownException e){
			e.printStackTrace();

		}*/

