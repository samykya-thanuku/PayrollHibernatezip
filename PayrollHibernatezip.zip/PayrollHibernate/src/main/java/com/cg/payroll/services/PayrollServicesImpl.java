package com.cg.payroll.services;

import java.sql.SQLException;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;

@Component("services")
public class PayrollServicesImpl implements PayrollServices {
	@Autowired
	private PayrollDAOServices daoServices;
	/*public PayrollServicesImpl() throws PayrollServicesDownException {
		daoServices=new PayrollDAOServicesImpl();
	}*/


	public int acceptAssociateDetails(String firstName, String lastName,String department, String designation, 
			String pancard, String emailId,int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber,
			String bankName,String ifscCode) throws SQLException {
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}  
	public boolean updateAssociateDetails(String firstName, String lastName,String department, String designation, 
			String pancard, String emailId,int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber,
			String bankName,String ifscCode) throws SQLException {
		//return false;
		return daoServices.updateAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException,SQLException {
		daoServices.getAssociate(associateId);
		if(getAssociateDetails(associateId)==null) throw new AssociateDetailsNotFoundException("Associate details not found");
		//Associate associate=this.getAssociateDetails(associateId);
		Associate associate=daoServices.getAssociate(associateId);
		if(associate!=null){
			associate.getSalary().setPersonalAllowance(0.3f*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
			float annualgrosssalary= associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getCompanyPf()+associate.getSalary().getHra();
			float annualtax;
			if(associate.getYearlyInvestmentUnder80C()>=(150000-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())) {
				associate.setYearlyInvestmentUnder80C((int) (150000-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()));
			}
			else {
				associate.setYearlyInvestmentUnder80C(associate.getYearlyInvestmentUnder80C());
			}
			if(annualgrosssalary>0 &&annualgrosssalary<=250000) {
				annualtax= 0;
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
				System.out.println(associate.getSalary().getHra());
				daoServices.updateAssociate(associate);
				return associate.getSalary().getNetSalary();
			}
			else if(annualgrosssalary>250000&&annualgrosssalary<=500000) {
				annualtax= (annualgrosssalary-250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f;
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				daoServices.updateAssociate(associate);
				return associate.getSalary().getNetSalary();
			}
			else if(annualgrosssalary>500000&&annualgrosssalary<=1000000) {
				annualtax= ((250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f+(annualgrosssalary-500000)*0.2f);
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				daoServices.updateAssociate(associate);
				return associate.getSalary().getNetSalary();
			}
			else {
				annualtax= ((250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f+500000*0.2f+(annualgrosssalary-1000000)*0.3f);
				associate.getSalary().setMonthlyTax(annualtax/12);
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				daoServices.updateAssociate(associate);
				return associate.getSalary().getNetSalary();
			}
		}
		
		return 0;
	}
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException,SQLException {

		
		if(daoServices.getAssociate(associateId)== null)
			throw new AssociateDetailsNotFoundException("Associate details not found");
		return daoServices.getAssociate(associateId);
	}
	public boolean doDeleteAssociate(int associateId) throws PayrollServicesDownException {
		return daoServices.deleteAssociate(associateId);
	}
	public List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {

		return daoServices.getAssociates();
	}


	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, float yearlyInvestmentUnder80C, float basicSalary, float epf,
			float companyPf, float accountNumber, String bankName, String ifscCode)
			throws PayrollServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}


	public List<Associate> getAllAssociateDetails() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}


	public boolean acceptAssociateDetailsForUpdate(int associateId, String firstName, String lastName, String emailId,
			String department, String designation, String pancard, float yearlyInvestmentUnder80C, float basicSalary,
			float epf, float companyPf, float accountNumber, String bankName, String ifscCode) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean delete(Associate associate) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}



}
